#include "diseasecheckerbackend.h"
#include <algorithm>
#include <QSet>
#include <QFile>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>

// Threshold for urgent/complex selection
static const int COMPLEX_SYMPTOM_THRESHOLD = 6;

// static maps definition
QMap<QString, QPair<int,int>> DiseaseCheckerBackend::diseaseAgeRanges;
QMap<QString, QString> DiseaseCheckerBackend::diseaseGenderPref;

DiseaseCheckerBackend::DiseaseCheckerBackend() {}

void DiseaseCheckerBackend::initialize(const QStringList& allSymptoms)
{
    diseases.clear();

    diseases.push_back({"Pneumonia",
                        {"fever", "cough", "chest pain", "fatigue"},
                        "Pneumonia (Lung infection causing cough, fever, chest pain)",
                        "Seek medical attention. May require antibiotics/antivirals.",
                        "Maintain hydration, rest, avoid infection spread. Warm fluids and steam inhalation."});

    diseases.push_back({"COVID-19",
                        {"fever", "cough", "shortness of breath", "fatigue", "loss of taste", "loss of smell"},
                        "COVID-19 (Viral respiratory illness with cough, fever, breathlessness, etc.)",
                        "Isolation, rest, fluids. Contact healthcare provider for persistent symptoms.",
                        "Warm fluids, rest, monitor oxygen if available."});

    diseases.push_back({"Bronchitis",
                        {"cough", "chest pain", "fatigue", "sore throat"},
                        "Bronchitis (Inflammation of the airways with cough and chest discomfort).",
                        "Rest, fluids; see doctor if no improvement.",
                        "Steam inhalation, honey for cough (over age 1)."});

    diseases.push_back({"Asthma",
                        {"wheezing", "shortness of breath", "cough", "chest pain"},
                        "Asthma (Reversible airway narrowing; breathing difficulty).",
                        "Inhaled bronchodilators, avoid triggers.",
                        "Breathe moist air, avoid allergens."});

    diseases.push_back({"Common Cold",
                        {"cough", "runny nose", "sneezing", "sore throat", "headache"},
                        "Common Cold (Viral rhinitis: runny nose, cough, sneezing).",
                        "Usually self-resolves, fluids and rest.",
                        "Warm salt-water gargle, honey/ginger tea."});

    diseases.push_back({"Influenza (Flu)",
                        {"fever", "headache", "fatigue", "muscle aches", "cough"},
                        "Influenza (Flu: high fever, aches, fatigue, cough).",
                        "Antiviral medication if prescribed, fluids, rest.",
                        "Warm teas, hydration, paracetamol for fever."});

    diseases.push_back({"Lung Cancer",
                        {"cough", "chest pain", "fatigue", "weight loss"},
                        "Lung Cancer (Chronic cough, chest pain, fatigue, weight loss).",
                        "Consult physician for diagnosis, management.",
                        "N/A"});

    diseases.push_back({"Measles",
                        {"fever", "rash", "cough", "congestion"},
                        "Measles (Fever, red rash, runny nose, cough).",
                        "See doctor; supportive care at home.",
                        "Hydration, paracetamol for fever, vitamin A supplements."});

    diseases.push_back({"Heart Attack",
                        {"chest pain", "shortness of breath", "nausea", "fatigue"},
                        "Heart Attack (Chest pain, breathlessness, nausea, sweating).",
                        "EMERGENCY: Call ambulance. Hospital care.",
                        "Sit and rest, chew aspirin if not allergic."});

    diseases.push_back({"Mononucleosis",
                        {"fever", "sore throat", "fatigue", "swelling"},
                        "Mononucleosis (Mono: viral infection, fever, sore throat, swollen glands).",
                        "Rest, fluids. Avoid contact sports.",
                        "Gargle salt water, hydration, pain relief if needed."});

    diseases.push_back({"Strep Throat",
                        {"sore throat", "fever", "swelling", "headache"},
                        "Strep Throat (Bacterial pharyngitis: sore throat, fever, swelling).",
                        "Antibiotics needed (see doctor).",
                        "Warm fluids, avoid irritants, use throat lozenges."});

    // --- Add special "complex" disease that contains all known symptoms (optional) ---
    diseases.push_back({
        "Multiple/Complex Condition - Contact Doctor",
        allSymptoms,
        "Multiple symptoms across systems — may indicate a complex or serious condition.",
        "Contact your physician or emergency services for evaluation.",
        "Seek urgent medical attention; do not self-diagnose."
    });

    // Ensure every symptom is in at least one disease
    QSet<QString> allDiagnosedSymptoms;
    for (const DiseaseInfo& d : diseases)
        for (const QString& s : d.symptoms)
            allDiagnosedSymptoms.insert(s);

    for (const QString& s : allSymptoms) {
        if (!allDiagnosedSymptoms.contains(s)) {
            diseases.push_back({
                "General Symptom Syndrome",
                {s},
                QString("Generic diagnosis for '%1'. Symptom may indicate less common or non-specific conditions.").arg(s),
                "Please consult a doctor for proper evaluation.",
                "Symptomatic treatment, hydration, rest. Monitor and record your symptom pattern."
            });
        }
    }

    // initialize some simple heuristics for age/gender (can be extended)
    diseaseAgeRanges.clear();
    diseaseGenderPref.clear();

    diseaseAgeRanges["Measles"] = qMakePair(0, 12);
    diseaseAgeRanges["Mononucleosis"] = qMakePair(12, 30);
    diseaseAgeRanges["Lung Cancer"] = qMakePair(40, 120);
    diseaseAgeRanges["Heart Attack"] = qMakePair(40, 120);
    diseaseAgeRanges["Strep Throat"] = qMakePair(5, 50);

    // example gender pref (if you later add UTI) — default is no entry -> Any
    diseaseGenderPref["Urinary Tract Infection"] = "Female";
}

QString DiseaseCheckerBackend::diagnoseDetailed(const QStringList& selectedSymptoms)
{
    // URGENT early return: many symptoms => advise contacting doctor
    if (selectedSymptoms.size() >= COMPLEX_SYMPTOM_THRESHOLD) {
        QString output = "--- URGENT: Multiple symptoms detected ---\n";
        output += "You have selected multiple symptoms across systems. This may indicate a complex or serious condition. Please contact a doctor or seek urgent medical care immediately.\n";
        output += "Suggested action: Call your healthcare provider or emergency services.\n";
        return output.trimmed();
    }

    QVector<std::tuple<int, QString>> matches; // (symptoms matched, disease name)
    int maxMatched = 0;
    DiseaseInfo* bestDisease = nullptr;

    for (DiseaseInfo &d : diseases) {
        int matchCount = 0;
        for (const QString &symptom : selectedSymptoms) {
            if (d.symptoms.contains(symptom)) ++matchCount;
        }
        if (matchCount > 0) matches.push_back({matchCount, d.name});
        if (matchCount > maxMatched) {
            maxMatched = matchCount;
            bestDisease = &d;
        }
    }

    std::sort(matches.begin(), matches.end(),
              [](const auto& a, const auto& b) { return std::get<0>(a) > std::get<0>(b); });

    QString output = "--- Diagnosis Results ---\n";
    if (!bestDisease) return output + "No probable disease found.";

    output += "Most probable disease: " + bestDisease->name + " (" + bestDisease->summary + ")\n";
    output += "Suggested treatment: " + bestDisease->treatment + "\n";
    output += "Home remedies: " + bestDisease->remedies + "\n";
    output += QString("Matched symptoms: %1\n\nOther probable diseases:\n").arg(maxMatched);

    for (const auto& entry : matches) {
        if (std::get<1>(entry) != bestDisease->name)
            output += QString("- %1 (%2 symptoms matched)\n").arg(std::get<1>(entry)).arg(std::get<0>(entry));
    }
    return output.trimmed();
}

QString DiseaseCheckerBackend::diagnoseDetailed(const QStringList& selectedSymptoms, int age, const QString& gender)
{
    // URGENT early return: many symptoms => advise contacting doctor
    if (selectedSymptoms.size() >= COMPLEX_SYMPTOM_THRESHOLD) {
        QString output = "--- URGENT: Multiple symptoms detected ---\n";
        output += "You have selected multiple symptoms across systems. This may indicate a complex or serious condition. Please contact a doctor or seek urgent medical care immediately.\n";
        output += "Suggested action: Call your healthcare provider or emergency services.\n";
        output += QString("\nContext: Age=%1  Gender=%2").arg(age).arg(gender);
        return output.trimmed();
    }

    struct Scored {
        double score;
        int rawMatches;
        QString name;
    };

    QVector<Scored> scoredList;
    int maxRawMatches = 0;

    for (DiseaseInfo &d : diseases) {
        int matchCount = 0;
        for (const QString &symptom : selectedSymptoms) {
            if (d.symptoms.contains(symptom)) ++matchCount;
        }
        if (matchCount == 0) continue;

        double score = static_cast<double>(matchCount); // baseline

        // age boost / penalty
        if (diseaseAgeRanges.contains(d.name)) {
            QPair<int,int> range = diseaseAgeRanges[d.name];
            if (age >= range.first && age <= range.second) {
                score *= 1.20;
            } else {
                int dist = 0;
                if (age < range.first) dist = range.first - age;
                else if (age > range.second) dist = age - range.second;
                double penalty = std::max(0.0, 1.0 - std::min(0.5, dist / 100.0));
                score *= penalty;
            }
        }

        // gender preference
        if (diseaseGenderPref.contains(d.name)) {
            QString pref = diseaseGenderPref[d.name];
            if (!pref.isEmpty() && pref.compare("Any", Qt::CaseInsensitive) != 0) {
                if (pref.compare(gender, Qt::CaseInsensitive) == 0) score *= 1.25;
                else score *= 0.90;
            }
        }

        scoredList.push_back({score, matchCount, d.name});
        if (matchCount > maxRawMatches) maxRawMatches = matchCount;
    }

    std::sort(scoredList.begin(), scoredList.end(), [](const Scored &a, const Scored &b) {
        if (a.score == b.score) return a.rawMatches > b.rawMatches;
        return a.score > b.score;
    });

    QString output = "--- Diagnosis Results (age/gender aware) ---\n";
    if (scoredList.isEmpty()) return output + "No probable disease found.";

    QString bestName = scoredList.first().name;
    DiseaseInfo* bestDisease = nullptr;
    for (DiseaseInfo &d : diseases) if (d.name == bestName) { bestDisease = &d; break; }
    if (!bestDisease) return output + "No probable disease found.";

    double topScore = scoredList.first().score;
    if (topScore <= 0.0) topScore = 1.0;

    output += "Most probable disease: " + bestDisease->name + " (" + bestDisease->summary + ")\n";
    output += "Suggested treatment: " + bestDisease->treatment + "\n";
    output += "Home remedies: " + bestDisease->remedies + "\n";

    QStringList matched;
    for (const QString &sym : bestDisease->symptoms)
        for (const QString &inputSym : selectedSymptoms)
            if (sym.compare(inputSym, Qt::CaseInsensitive) == 0) { matched.append(sym); break; }

    output += QString("Matched symptoms: %1\n\nOther probable diseases (ranked):\n").arg(matched.join(", "));

    for (const Scored &s : scoredList) {
        double confidence = (s.score / topScore) * 100.0;
        output += QString("- %1 (score: %2, matched: %3, confidence: %4%)\n")
                      .arg(s.name)
                      .arg(QString::number(s.score, 'f', 2))
                      .arg(s.rawMatches)
                      .arg(QString::number(confidence, 'f', 1));
    }

    output += QString("\nContext: Age=%1  Gender=%2").arg(age).arg(gender);

    return output.trimmed();
}
