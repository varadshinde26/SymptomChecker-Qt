#ifndef DISEASECHECKERBACKEND_H
#define DISEASECHECKERBACKEND_H

#include <QString>
#include <QStringList>
#include <QMap>
#include <QVector>
#include <tuple>
#include <QPair>

class DiseaseCheckerBackend
{
public:
    DiseaseCheckerBackend();
    void initialize(const QStringList& allSymptoms);
    QString diagnoseDetailed(const QStringList& selectedSymptoms);
    QString diagnoseDetailed(const QStringList& selectedSymptoms, int age, const QString& gender);

private:
    struct DiseaseInfo {
        QString name;
        QStringList symptoms;
        QString summary;
        QString treatment;
        QString remedies;
    };

    QVector<DiseaseInfo> diseases;

    static QMap<QString, QPair<int,int>> diseaseAgeRanges;
    static QMap<QString, QString> diseaseGenderPref;
};

#endif // DISEASECHECKERBACKEND_H
