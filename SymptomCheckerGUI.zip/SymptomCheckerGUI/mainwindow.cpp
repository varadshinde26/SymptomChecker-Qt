#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>
#include <QFileDialog>
#include <QClipboard>
#include <QApplication>
#include <QDateTime>
#include <QDialog>
#include <QVBoxLayout>
#include <QTextEdit>
#include <QTextStream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // --------------------------
    // Symptom List Initialization
    // --------------------------
    symptomList << "fever" << "cough" << "headache" << "fatigue"
                << "shortness of breath" << "chest pain" << "sore throat"
                << "runny nose" << "sneezing" << "nausea" << "vomiting"
                << "muscle aches" << "diarrhea" << "loss of taste" << "loss of smell"
                << "rash" << "dizziness" << "abdominal pain" << "joint pain"
                << "swelling" << "night sweats" << "weight loss" << "loss of appetite"
                << "irritability" << "confusion" << "chills" << "blurred vision"
                << "back pain" << "ear pain" << "eye redness" << "tearing"
                << "mouth ulcers" << "short temper" << "anxiety" << "palpitations"
                << "wheezing" << "leg cramps" << "frequent urination" << "excessive thirst"
                << "constipation" << "itching" << "yellow skin"
                << "dark urine" << "blood in stool" << "hemorrhage"
                << "stiff neck" << "seizures" << "sensitivity to light" << "congestion";

    ui->symptomListWidget->addItems(symptomList);
    ui->symptomListWidget->setSelectionMode(QAbstractItemView::MultiSelection);

    backend.initialize(symptomList);

    // --------------------------
    // Age and Gender Initialization
    // --------------------------
    ui->ageSpinBox->setRange(0, 120);
    if (ui->genderComboBox->count() == 0) {
        ui->genderComboBox->addItems({"Any", "Male", "Female", "Other"});
    }

    ui->selectedSummaryLabel->setText("Selected symptoms: (none)");
}

MainWindow::~MainWindow()
{
    delete ui;
}

//
// ===========================================================
// Helper Functions
// ===========================================================
//

void MainWindow::updateSelectedSummary()
{
    QString text;
    for (QListWidgetItem *item : ui->symptomListWidget->selectedItems())
        text += item->text() + ", ";

    if (!text.isEmpty()) text.chop(2);

    ui->selectedSummaryLabel->setText("Selected symptoms: " +
                                      (text.isEmpty() ? "(none)" : text));
}

QStringList MainWindow::gatherSelectedSymptoms() const
{
    QStringList list;
    for (QListWidgetItem *item : ui->symptomListWidget->selectedItems())
        list << item->text();
    return list;
}

void MainWindow::displayResultText(const QString &text)
{
    ui->resultTextEdit->setPlainText(text);
}

void MainWindow::addToHistory(const QString &entry)
{
    historyRecords.prepend(entry);
    if (historyRecords.size() > 100) historyRecords.removeLast();
}

//
// ===========================================================
// Levenshtein Functions
// ===========================================================
//

int MainWindow::levenshteinDistance(const QString &s1, const QString &s2)
{
    int n = s1.size(), m = s2.size();
    QVector<QVector<int>> d(n + 1, QVector<int>(m + 1));

    for (int i = 0; i <= n; i++) d[i][0] = i;
    for (int j = 0; j <= m; j++) d[0][j] = j;

    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= m; j++)
        {
            int cost = (s1[i - 1].toLower() == s2[j - 1].toLower()) ? 0 : 1;
            d[i][j] = std::min({d[i - 1][j] + 1,
                                d[i][j - 1] + 1,
                                d[i - 1][j - 1] + cost});
        }
    }

    return d[n][m];
}

QString MainWindow::findClosestSymptom(const QString &input,
                                       const QStringList &list,
                                       int maxDist)
{
    QString best;
    int bestDist = maxDist + 1;

    for (const QString &s : list)
    {
        int dist = levenshteinDistance(input, s);
        if (dist < bestDist) {
            bestDist = dist;
            best = s;
        }
    }

    return (bestDist <= maxDist) ? best : QString();
}

//
// ===========================================================
// Button Slots
// ===========================================================
//

void MainWindow::on_addSymptomButton_clicked()
{
    QString input = ui->manualSymptomInput->text().trimmed();

    if (input.isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Please enter a symptom.");
        return;
    }

    QString match = findClosestSymptom(input.toLower(), symptomList);

    if (match.isEmpty()) {
        QMessageBox::information(this, "Not Found", "Symptom not recognized.");
        return;
    }

    QList<QListWidgetItem*> items =
        ui->symptomListWidget->findItems(match, Qt::MatchExactly);

    if (!items.isEmpty()) {
        items.first()->setSelected(true);
    }

    ui->manualSymptomInput->clear();
    updateSelectedSummary();
}

void MainWindow::on_clearSymptomsButton_clicked()
{
    for (int i = 0; i < ui->symptomListWidget->count(); i++)
        ui->symptomListWidget->item(i)->setSelected(false);

    ui->manualSymptomInput->clear();
    updateSelectedSummary();
}

void MainWindow::on_copyButton_clicked()
{
    QString text = ui->resultTextEdit->toPlainText();

    if (text.isEmpty()) {
        QMessageBox::information(this, "Copy", "Nothing to copy.");
        return;
    }

    QApplication::clipboard()->setText(text);
    QMessageBox::information(this, "Copied", "Result copied to clipboard.");
}

void MainWindow::on_saveReportButton_clicked()
{
    QString text = ui->resultTextEdit->toPlainText();

    if (text.isEmpty()) {
        QMessageBox::information(this, "Save", "No report to save.");
        return;
    }

    QString filename = QFileDialog::getSaveFileName(
        this,
        "Save Report",
        "diagnosis_" + QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss") + ".txt",
        "Text Files (*.txt)");

    if (filename.isEmpty()) return;

    QFile f(filename);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to save file.");
        return;
    }

    QTextStream out(&f);
    out << text;

    QMessageBox::information(this, "Saved", "Report saved.");
}

void MainWindow::on_exportButton_clicked()
{
    QStringList symptoms = gatherSelectedSymptoms();

    if (symptoms.isEmpty()) {
        QMessageBox::information(this, "Export", "No symptoms selected.");
        return;
    }

    int age = ui->ageSpinBox->value();
    QString gender = ui->genderComboBox->currentText();

    QStringList normalized = symptoms;
    for (QString &s : normalized) s = s.toLower().trimmed();
    normalized.removeDuplicates();

    QString diagnosis = backend.diagnoseDetailed(normalized, age, gender);

    QString filename = QFileDialog::getSaveFileName(
        this,
        "Export CSV",
        "diagnosis_" + QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss") + ".csv",
        "CSV Files (*.csv)");

    if (filename.isEmpty()) return;

    QFile f(filename);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Unable to write CSV.");
        return;
    }

    QTextStream out(&f);
    out << "timestamp,age,gender,symptoms,diagnosis\n";
    out << "\"" << QDateTime::currentDateTime().toString(Qt::ISODate) << "\","
        << "\"" << age << "\","
        << "\"" << gender << "\","
        << "\"" << symptoms.join(";") << "\","
        << "\"" << diagnosis.replace("\"", "\"\"") << "\"\n";

    QMessageBox::information(this, "Export", "CSV exported.");
}

void MainWindow::on_resetButton_clicked()
{
    on_clearSymptomsButton_clicked();
    ui->ageSpinBox->setValue(25);
    ui->genderComboBox->setCurrentText("Any");
    ui->resultTextEdit->clear();

    QMessageBox::information(this, "Reset", "All fields reset.");
}

void MainWindow::on_helpButton_clicked()
{
    QMessageBox::information(
        this,
        "Help",
        "1. Select symptoms or type manually.\n"
        "2. Set age and gender.\n"
        "3. Click Diagnose.\n"
        "4. Use Save or Export for records.\n"
        "\nThis tool is for educational use only.");
}

void MainWindow::on_historyButton_clicked()
{
    QDialog dlg(this);
    dlg.setWindowTitle("Diagnosis History");

    QVBoxLayout *layout = new QVBoxLayout(&dlg);
    QTextEdit *edit = new QTextEdit();
    edit->setReadOnly(true);

    QString text;
    for (const QString &h : historyRecords)
        text += h + "\n------------------\n";

    edit->setPlainText(text.isEmpty() ? "(no history)" : text);
    layout->addWidget(edit);

    dlg.resize(600, 400);
    dlg.exec();
}

void MainWindow::on_diagnoseButton_clicked()
{
    QStringList symptoms = gatherSelectedSymptoms();

    if (symptoms.isEmpty()) {
        QMessageBox::warning(this, "No Symptoms", "Please select at least one symptom.");
        return;
    }

    QStringList normalized = symptoms;
    for (QString &s : normalized) s = s.toLower().trimmed();
    normalized.removeDuplicates();

    int age = ui->ageSpinBox->value();
    QString gender = ui->genderComboBox->currentText();

    QString report = backend.diagnoseDetailed(normalized, age, gender);
    QString header = QString("Age: %1   Gender: %2\n\n").arg(age).arg(gender);

    QString output = header + report;
    displayResultText(output);

    addToHistory(QDateTime::currentDateTime().toString(Qt::ISODate) +
                 "\n" + output);
}
