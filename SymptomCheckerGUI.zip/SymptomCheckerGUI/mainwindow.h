#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStringList>
#include <QVector>
#include "diseasecheckerbackend.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    // Matching helper functions
    int levenshteinDistance(const QString& s1, const QString& s2);
    QString findClosestSymptom(const QString& inputSymptom,
                               const QStringList& symptomList,
                               int maxDistance = 3);

private slots:
    // Button slots
    void on_addSymptomButton_clicked();
    void on_diagnoseButton_clicked();
    void on_clearSymptomsButton_clicked();
    void on_copyButton_clicked();
    void on_saveReportButton_clicked();
    void on_exportButton_clicked();
    void on_resetButton_clicked();
    void on_helpButton_clicked();
    void on_historyButton_clicked();

private:
    Ui::MainWindow *ui;
    QStringList symptomList;
    DiseaseCheckerBackend backend;
    QVector<QString> historyRecords;

    // Helper functions used in .cpp
    void updateSelectedSummary();
    void displayResultText(const QString &text);
    QStringList gatherSelectedSymptoms() const;
    void addToHistory(const QString &entry);
};

#endif // MAINWINDOW_H
